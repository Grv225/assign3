using Microsoft.VisualStudio.TestTools.UnitTesting;
using Assignment3;
using Assignment3.Helpers;

namespace Assignment3.Tests
{
    [TestClass]
    public class SerializationTests
    {
        [TestMethod]
        public void TestSerialization()
        {
            SLL list = new SLL();
            list.AddLast(new User("Alice", 25));
            list.AddLast(new User("Bob", 30));

            string fileName = "LinkedListData.bin";
            SerializationHelper.SerializeLinkedList(list, fileName);
            SLL deserializedList = SerializationHelper.DeserializeLinkedList(fileName);

            Assert.AreEqual(list.Count(), deserializedList.Count());
            Assert.AreEqual(list.GetValue(0).Name, deserializedList.GetValue(0).Name);
            Assert.AreEqual(list.GetValue(0).Age, deserializedList.GetValue(0).Age);
        }
    }
}

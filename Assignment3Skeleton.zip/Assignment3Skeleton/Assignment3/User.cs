﻿using System.Runtime.Serialization;

[DataContract]
public class User
{
    [DataMember]
    public string Name { get; set; }

    [DataMember]
    public int Age { get; set; }

    public User() { }

    public User(string name, int age)
    {
        Name = name;
        Age = age;
    }

    public override bool Equals(object obj)
    {
        if (obj is User user)
        {
            return Name == user.Name && Age == user.Age;
        }
        return false;
    }

    public override int GetHashCode()
    {
        return Name.GetHashCode() ^ Age.GetHashCode();
    }
}

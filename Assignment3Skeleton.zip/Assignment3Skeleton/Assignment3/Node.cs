﻿using System;
using System.Runtime.Serialization;

namespace Assignment3
{
    [DataContract]
    public class Node
    {
        [DataMember]
        public User _value { get; set; }

        [DataMember]
        public Node _next { get; set; }

        public Node() { }

        public Node(User value)
        {
            this._value = value;
            this._next = null;
        }
    }
}

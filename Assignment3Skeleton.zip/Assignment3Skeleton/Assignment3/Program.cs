﻿using System;
using Assignment3.Helpers;

namespace Assignment3
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            SLL linkedList = new SLL();
            linkedList.AddLast(new User("Alice", 25));
            linkedList.AddLast(new User("Bob", 30));
            linkedList.AddFirst(new User("Charlie", 20));

            for (int i = 0; i < linkedList.Count(); i++)
            {
                User user = linkedList.GetValue(i);
                Console.WriteLine($"User {i + 1}: {user.Name}, {user.Age} years old");
            }

            linkedList.Replace(new User("David", 35), 1);

            linkedList.RemoveFirst();

            bool containsBob = linkedList.Contains(new User("Bob", 30));
            Console.WriteLine($"List contains Bob: {containsBob}");

            Console.WriteLine("\nAfter modifications:");
            for (int i = 0; i < linkedList.Count(); i++)
            {
                User user = linkedList.GetValue(i);
                Console.WriteLine($"User {i + 1}: {user.Name}, {user.Age} years old");
            }

            string fileName = "LinkedListData.bin";
            SerializationHelper.SerializeLinkedList(linkedList, fileName);
            SLL deserializedList = SerializationHelper.DeserializeLinkedList(fileName);

            Console.WriteLine("\nDeserialized list:");
            for (int i = 0; i < deserializedList.Count(); i++)
            {
                User user = deserializedList.GetValue(i);
                Console.WriteLine($"User {i + 1}: {user.Name}, {user.Age} years old");
            }
        }
    }
}

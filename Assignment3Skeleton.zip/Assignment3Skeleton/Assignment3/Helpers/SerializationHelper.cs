﻿using System;
using System.IO;
using System.Runtime.Serialization;

namespace Assignment3.Helpers
{
    public static class SerializationHelper
    {
        public static void SerializeLinkedList(SLL list, string fileName)
        {
            DataContractSerializer serializer = new DataContractSerializer(typeof(SLL));
            using (FileStream stream = File.Create(fileName))
            {
                serializer.WriteObject(stream, list);
            }
        }

        public static SLL DeserializeLinkedList(string fileName)
        {
            DataContractSerializer serializer = new DataContractSerializer(typeof(SLL));
            using (FileStream stream = File.OpenRead(fileName))
            {
                return (SLL)serializer.ReadObject(stream);
            }
        }
    }
}

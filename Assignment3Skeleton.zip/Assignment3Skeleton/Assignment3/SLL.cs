﻿using System;

namespace Assignment3
{
    [Serializable]
    public class SLL : ILinkedListADT
    {
        private Node Head;
        public int count { get; set; }

        public bool IsEmpty()
        {
            return Head == null;
        }

        public void Clear()
        {
            Head = null;
            count = 0;
        }

        public void AddLast(User value)
        {
            Node newNode = new Node(value);
            if (Head == null)
            {
                Head = newNode;
            }
            else
            {
                Node node = Head;
                while (node._next != null)
                {
                    node = node._next;
                }
                node._next = newNode;
            }
            count++;
        }

        public void AddFirst(User value)
        {
            Node newNode = new Node(value);
            newNode._next = Head;
            Head = newNode;
            count++;
        }

        public void Add(User value, int index)
        {
            if (index < 0 || index > count)
            {
                throw new ArgumentOutOfRangeException("Out of Range");
            }

            Node newNode = new Node(value);

            if (index == 0)
            {
                AddFirst(value);
            }
            else
            {
                Node node = Head;
                Node prevNode = null;

                for (int i = 0; i < index; i++)
                {
                    prevNode = node;
                    node = node._next;
                }
                prevNode._next = newNode;
                newNode._next = node;
                count++;
            }
        }

        public void Replace(User value, int index)
        {
            if (index < 0 || index >= count)
            {
                throw new ArgumentOutOfRangeException("Out of Range");
            }

            Node node = Head;
            for (int i = 0; i < index; i++)
            {
                node = node._next;
            }
            node._value = value;
        }

        public int Count()
        {
            return count;
        }

        public void RemoveFirst()
        {
            if (Head != null)
            {
                Head = Head._next;
                count--;
            }
        }

        public void RemoveLast()
        {
            if (Head == null) return;

            if (Head._next == null)
            {
                Head = null;
            }
            else
            {
                Node node = Head;
                while (node._next._next != null)
                {
                    node = node._next;
                }
                node._next = null;
            }
            count--;
        }

        public void Remove(int index)
        {
            if (index < 0 || index >= count)
            {
                throw new ArgumentOutOfRangeException("Out of Range");
            }

            if (index == 0)
            {
                RemoveFirst();
            }
            else
            {
                Node node = Head;
                Node prevNode = null;

                for (int i = 0; i < index; i++)
                {
                    prevNode = node;
                    node = node._next;
                }
                prevNode._next = node._next;
                count--;
            }
        }

        public User GetValue(int index)
        {
            if (index < 0 || index >= count)
            {
                throw new ArgumentOutOfRangeException("Out of Range");
            }

            Node node = Head;
            for (int i = 0; i < index; i++)
            {
                node = node._next;
            }
            return node._value;
        }

        public int IndexOf(User value)
        {
            Node node = Head;
            int index = 0;
            while (node != null)
            {
                if (node._value.Equals(value))
                {
                    return index;
                }
                node = node._next;
                index++;
            }
            return -1;
        }

        public bool Contains(User value)
        {
            return IndexOf(value) != -1;
        }
    }
}
